﻿#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <conio.h>
#include "estruturas.h"
#include "visuais.h"

//FUNÇÕES UTILITÁRIAS

void limpatela(){
    system("cls");
}

void pausatela(){
    system("pause");
}

char lerTecla(){
    return getch();
}




//IMPLEMENTAÇÃO INICIALIZAÇÃO DE ESTRUTURAS

void inicializar_jogador(jogador j[4], int id_jogador, char nome_jogador[20], float dinheiro_jogador, int campos_jogador){
    for(int i=0; i<=3; i++){
        if (i == 0){
            printf("Digite o nome do jogador %i: ", i+1);
            fgets(j[i].nome_jogador, sizeof(j[i].nome_jogador), stdin);
            j[i].nome_jogador[strcspn(j[i].nome_jogador, "\n")] = '\0';
            j[i].dinheiro_jogador = 1000;
            j[i].campos_jogador = malloc(sizeof(campo));
        }

    }
}



//IMPLEMENTAÇÃO FUNÇÕES DE MENU

bool iniciar_jogo(){
    desenharMenu();
    lerTecla();
    return true;
}




