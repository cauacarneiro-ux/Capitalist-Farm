#ifndef FUNCOES_H
#define FUNCOES_H
#include "estruturas.h"

extern jogador j[4];
extern int id_jogador;
extern char nome_jogador[20];
extern float dinheiro_jogador;
extern campo campos_jogador;

extern producao *p;
extern int id_producao;
extern char nome_producao;
extern float custo_producao;
extern float lucro_producao;

extern campo *c;
extern int id_campo;
extern char tipo_campo[10];
extern producao *producao_campo;

extern eventos *e;
extern int id_eventos;
extern char nome_eventos[20];
extern int tipo_eventos;


//FUN��ES PARA INICIALIZA��O DE ESTRUTURAS

void inicializar_jogador(jogador j[4], int id_jogador, char nome_jogador[20], float dinheiro_jogador, campo *campos_jogador);
void inicializar_producao(producao *p, int id_producao, char nome_producao[20], float custo_producao, float lucro_producao);
void inicializar_campo(campo *c, int id_campo, char tipo_campo[10], producao *producao_campo);
void inicializar_evento(eventos *e, int id_eventos, char nome_eventos[20], int tipo_eventos);




//FUN��ES DO MENU DO JOGO

bool iniciar_jogo();





//FUN��ES DIVERSAS

void limpatela();
void pausatela();
char letTecla();



#endif
